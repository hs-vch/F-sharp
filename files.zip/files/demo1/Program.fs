﻿open System


//EN PROGRAMACIÓN SOLO HAY DOS FORMAS DE HACER LOOP. TODO PROGRAMA QUE INTERACTUA CON EL USUARIO ES UN LOOP INFINITO.

// Loop infitivo pedir nombre con  rec
let rec pedirNombre()=
    printfn "Entra tu nombre: "
    let linea= Console.ReadLine()

    match linea with
    | "SALIR" -> printfn "Chau"
    |_-> 
        printfn $"Hola {linea}"
        pedirNombre()

pedirNombre()

//PEDIR UNA SECUENCIA DE NOMBRES DE AMIGOS, GUARDARLOS EN EL DISCO DURO Y LEERLOS



