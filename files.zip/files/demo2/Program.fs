﻿open System

open System.IO




let lineas = File.ReadAllLines("demo.txt")
lineas 
|> Seq.iter (fun e-> printfn $"{e}") //imprime en linea por linea


