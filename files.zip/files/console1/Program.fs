﻿open System
open System.Threading

type BulletState = {
    X: int
    Y: int
    Fired: bool
}

type MoonState = 
    | Orbiting of float  
    | Exploding of int * (int * int)  
    | Respawning of int * (int * int) 

type State = {
    Tick: int
    Timer: int
    Continuar: bool
    AlienX: int
    AlienY: int
    BulletList: BulletState list
    Moon: MoonState
    Score: int
}

let eventClock = 20
let oneSecond = 1000 / eventClock
let screenWidth = Console.BufferWidth
let screenHeight = Console.BufferHeight
let centerX = screenWidth / 2 - 1
let centerY = screenHeight / 2 - 1
let moonOrbitRadius = 8.0
let moonAngularSpeed = 2.0 * Math.PI / (float oneSecond * 5.0)

let initialState = {
    Tick = 0
    Timer = 0
    Continuar = true
    AlienX = centerX
    AlienY = centerY
    BulletList = []
    Moon = Orbiting 0.0
    Score = 0
}

let displayMessageAt x y color (message: string) =
    let x' = max 0 (min (screenWidth - message.Length) x)
    let y' = max 0 (min (screenHeight - 1) y)
    let oldColor = Console.ForegroundColor
    Console.ForegroundColor <- color
    Console.SetCursorPosition(x', y')
    Console.Write message
    Console.ForegroundColor <- oldColor

let polarToCartesian r theta =
    let x = centerX + int (2.0 * r * cos theta) 
    let y = centerY - int (r * sin theta)       
    (x, y)

let checkCollision bullet (theta: float) =
    let (moonX, moonY) = polarToCartesian moonOrbitRadius theta
    abs(bullet.X - moonX) < 2 && abs(bullet.Y - moonY) < 2

let updateTick state = { state with Tick = state.Tick + 1 }

let createBullet state =
    { X = state.AlienX + 2; Y = state.AlienY; Fired = true }

let updateBulletKeyboard key state =
    match key with
    | ConsoleKey.Spacebar -> // Disparar a la derecha
        { state with BulletList = { X = state.AlienX + 2; Y = state.AlienY; Fired = true } :: state.BulletList }
    | ConsoleKey.A ->       // Disparar a la izquierda
        { state with BulletList = { X = state.AlienX - 2; Y = state.AlienY; Fired = false } :: state.BulletList }
    | _ -> state


let updateAlienKeyboard key state =
    let newX, newY =
        match key with
        | ConsoleKey.UpArrow -> state.AlienX, max 0 (state.AlienY - 1)
        | ConsoleKey.DownArrow -> state.AlienX, min (screenHeight - 1) (state.AlienY + 1)
        | ConsoleKey.RightArrow -> min (screenWidth - 2) (state.AlienX + 1), state.AlienY
        | ConsoleKey.LeftArrow -> max 0 (state.AlienX - 1), state.AlienY
        | _ -> state.AlienX, state.AlienY
    { state with AlienX = newX; AlienY = newY }

let updateKeyboard key state =
    state
    |> updateAlienKeyboard key
    |> updateBulletKeyboard key

let updateExitState state =
    if Console.KeyAvailable then
        match Console.ReadKey(true).Key with
        | ConsoleKey.Escape -> { state with Continuar = false }
        | key -> updateKeyboard key state
    else state

let updateTimer state =
    if state.Tick % oneSecond = 0 then { state with Timer = state.Timer + 1 }
    else state

let updateMoon state =
    match state.Moon with
    | Orbiting theta -> 
        { state with Moon = Orbiting (theta + moonAngularSpeed) }
    | Exploding (1, pos) -> 
        { state with Moon = Respawning (30, pos) } 
    | Exploding (frames, pos) -> 
        { state with Moon = Exploding (frames - 1, pos) }
    | Respawning (1, (x, y)) -> 
        let dx = float (x - centerX)
        let dy = float (centerY - y)
        let theta = Math.Atan2(dy, dx/2.0)
        { state with Moon = Orbiting theta } 
    | Respawning (frames, pos) -> 
        { state with Moon = Respawning (frames - 1, pos) }

let updateBulletsAndCollisions state =
    let mutable hitPosition = None
    
    let newBulletList = 
        state.BulletList
        |> List.choose (fun bullet ->
            let newX = if bullet.Fired then bullet.X + 1 else bullet.X - 1
            if newX < 0 || newX >= screenWidth then
                None
            else
                match state.Moon with
                | Orbiting theta when checkCollision { bullet with X = newX } theta ->
                    let pos = polarToCartesian moonOrbitRadius theta
                    hitPosition <- Some pos
                    None
                | _ ->
                    Some { bullet with X = newX }
        )
    
    match hitPosition with
    | Some pos ->
        { state with 
            BulletList = newBulletList
            Score = state.Score + 1
            Moon = Exploding (10, pos) }
    | None ->
        { state with BulletList = newBulletList }

let updateState state =
    state
    |> updateTick
    |> updateExitState
    |> updateTimer
    |> updateMoon
    |> updateBulletsAndCollisions
    |> fun s -> if s.Timer >= 200 then { s with Continuar = false } else s

let displayMoon state =
    match state.Moon with
    | Orbiting theta ->
        let x, y = polarToCartesian moonOrbitRadius theta
        displayMessageAt x y ConsoleColor.Yellow "👾"
    | Exploding (_, (x, y)) ->
        displayMessageAt x y ConsoleColor.Red "💥"
    | Respawning (_, (x, y)) ->
        displayMessageAt x y ConsoleColor.DarkYellow "🌑"

let clearMoon state =
    match state.Moon with
    | Orbiting theta ->
        let x, y = polarToCartesian moonOrbitRadius theta
        displayMessageAt x y ConsoleColor.Black "  "
    | Exploding (_, (x, y)) ->
        displayMessageAt x y ConsoleColor.Black "  "
    | Respawning (_, (x, y)) ->
        displayMessageAt x y ConsoleColor.Black "  "

let displayAlien state =
    displayMessageAt state.AlienX state.AlienY ConsoleColor.Green "👽"

let clearAlien state =
    displayMessageAt state.AlienX state.AlienY ConsoleColor.Black "  "

let displayBullets state =
    state.BulletList
    |> List.iter (fun bullet -> displayMessageAt bullet.X bullet.Y ConsoleColor.Red "=>")

let clearBullets state =
    state.BulletList
    |> List.iter (fun bullet -> displayMessageAt bullet.X bullet.Y ConsoleColor.Black "  ")

let displayUI state =
    let msg = $"Tiempo: {state.Timer}/200 | Puntos: {state.Score}"
    displayMessageAt (screenWidth - msg.Length) 0 ConsoleColor.Cyan msg

let displayGameOver state =
    Console.Clear()
    let msg = $"¡Juego Terminado! Puntuación: {state.Score}"
    displayMessageAt (centerX - msg.Length / 2) centerY ConsoleColor.Magenta msg
    Thread.Sleep 3000

let rec evenLoop state =
    if state.Continuar then
        clearMoon state
        clearAlien state
        clearBullets state
        
        let newState = updateState state
        
        displayUI newState
        displayMoon newState
        displayAlien newState
        displayBullets newState
        
        Thread.Sleep eventClock
        evenLoop newState
    else
        displayGameOver state

Console.CursorVisible <- false
Console.Clear()

evenLoop initialState
Console.CursorVisible <- true

