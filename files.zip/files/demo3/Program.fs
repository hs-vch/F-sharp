﻿open System
open System.IO

let lineas = 
    Seq.initInfinite (fun _ ->
        printf "Entra un nombre: "
        Console.ReadLine()
    )
    |> Seq.takeWhile (fun e -> e <> "SALIR")
    |> Seq.toList

// Versión con recursividad
let obtenerLineas() =
    let rec preguntarNombre acc =
        printf "Entra un nombre: "
        match Console.ReadLine() with
        | "SALIR" -> acc |> List.rev
        | linea -> preguntarNombre (linea::acc)
    preguntarNombre []

// Tarea modificar el programa para que no borre la base de datos calificable
File.AppendAllLines("demo.txt", lineas)
