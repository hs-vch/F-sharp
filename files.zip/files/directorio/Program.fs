﻿open System
open System.IO
open System.Text.Json

type Amigo = {
    Nombre: string
    Apellido: string
    Telefono: string
    Email: string
}

let rutaArchivo = "amigos.json"

// Cargar amigos desde archivo JSON
let cargarAmigos() =
    if File.Exists(rutaArchivo) then
        try
            File.ReadAllText(rutaArchivo) 
            |> JsonSerializer.Deserialize<Amigo list>
        with _ -> []
    else []

// Guardar amigos en archivo JSON
let guardarAmigos amigos =
    try
        let json = JsonSerializer.Serialize(amigos)
        File.WriteAllText(rutaArchivo, json)
    with ex -> printfn $"Error al guardar: {ex.Message}"

// Función para agregar nuevos amigos
let rec agregarAmigos() =
    Console.Clear()
    printfn "AGREGAR NUEVO AMIGO"
    printf "Nombre:    "
    let nombre = Console.ReadLine()
    printf "Apellido:  "
    let apellido = Console.ReadLine()
    printf "Teléfono:  "
    let telefono = Console.ReadLine()
    printf "Email:     "
    let email = Console.ReadLine()

    let nuevoAmigo = {
        Nombre = nombre
        Apellido = apellido
        Telefono = telefono
        Email = email
    }

    printf "\n¿Desea agregar otro amigo? (s/n): "
    match Console.ReadLine().ToLower() with
    | "s" -> nuevoAmigo :: agregarAmigos()
    | _ -> [nuevoAmigo]

// Mostrar lista de amigos formateada
let mostrarAmigos amigos =
    Console.Clear()
    printfn "%-20s %-20s %-15s %-30s" "NOMBRE" "APELLIDO" "TELÉFONO" "EMAIL"
    printfn "%s" (String.replicate 85 "-")
    
    amigos
    |> List.iter (fun a ->
        printfn "%-20s %-20s %-15s %-30s" a.Nombre a.Apellido a.Telefono a.Email)
    
    printfn "\nPresione cualquier tecla para continuar..."
    Console.ReadKey() |> ignore

// Buscar amigos por nombre o apellido
let buscarAmigos amigos =
    Console.Clear()
    printfn "BUSCAR AMIGOS"
    printfn "1. Por Nombre"
    printfn "2. Por Apellido"
    printf "Seleccione opción: "
    
    match Console.ReadLine() with
    | "1" ->
        printf "Ingrese nombre: "
        let nombre = Console.ReadLine()
        amigos |> List.filter (fun a -> a.Nombre.ToLower().Contains(nombre.ToLower()))
    | "2" ->
        printf "Ingrese apellido: "
        let apellido = Console.ReadLine()
        amigos |> List.filter (fun a -> a.Apellido.ToLower().Contains(apellido.ToLower()))
    | _ ->
        printfn "Opción inválida"
        []

// Menú principal
[<EntryPoint>]
let main argv =
    let mutable amigos = cargarAmigos()
    
    while true do
        Console.Clear()
        printfn "DIRECTORIO DE AMIGOS"
        printfn "1. Agregar amigos"
        printfn "2. Mostrar todos"
        printfn "3. Buscar amigos"
        printfn "4. Salir"
        printf "Seleccione opción: "
        
        match Console.ReadLine() with
        | "1" ->
            let nuevos = agregarAmigos()
            amigos <- amigos @ nuevos
            guardarAmigos amigos
        | "2" ->
            mostrarAmigos amigos
        | "3" ->
            let resultados = buscarAmigos amigos
            if resultados.Length > 0 then
                mostrarAmigos resultados
            else
                printfn "\nNo se encontraron coincidencias"
                Console.ReadKey() |> ignore
        | "4" ->
            printfn "\n¡Hasta pronto!"
            Environment.Exit(0)
        | _ ->
            printfn "\nOpción inválida"
            Console.ReadKey() |> ignore
    
    0