﻿open System

let generarNumeroSeq min max =
    let random = Random()
    Seq.initInfinite (fun _ -> random.Next(min, max + 1))
    |> Seq.head  // Tomamos el primer elemento de la secuencia infinita

// Uso:
let numero = generarNumeroSeq 1 10
printfn $"Número aleatorio: {numero}"



let lista =
    Seq.initInfinite (fun _ -> Random().Next(1, 11)) |> Seq.distinct |> Seq.take 5 |> Seq.toList 


printfn $"{lista}"